#!/usr/bin/env bash
set -ev
which tar
# unzip ccc_convert.zip
# env
# echo "Calling ls"
# ls
#cwl-runner workflows/read_and_clean.cwl pdbfile.yml